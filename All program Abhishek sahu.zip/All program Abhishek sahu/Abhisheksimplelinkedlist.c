/*
simple linked list
Abhishek sahu
*/


#include<stdio.h>
#include<stdlib.h>

struct A{
   int data;
   struct A * next;
};



void linklisttraverse(struct A* ptr)
{
struct A *temp;
temp=ptr;

while(temp!=0)
{
printf(" Element: %d\n",temp->data);
temp=temp->next;
}

}




struct A * insertAtFirst(struct A *head,int data)
{

struct A * ptr=(struct A*)malloc (sizeof(struct A));
ptr->next=head;
ptr->data=data;return ptr;

}



struct A * insertIndex(struct A *head,int data,int index)
{
struct A * ptr=(struct A*)malloc (sizeof(struct A));
 struct A *p=head;
int i=0;
while(i!=index-1)
{

   p=p->next;
     i++;
}
ptr->data=data;
ptr->next=p->next;
p->next=ptr;
}

struct A * insertEnd(struct A *head,int data)
{
struct A * ptr=(struct A*)malloc (sizeof(struct A));
 ptr->data=data;
struct A * p=head;

while(p->next!=0)
{

   p=p->next;
    
}
p->next=ptr;
ptr->next= 0;
return head;

}


struct  A* deleteFirst( struct A * head)
{
struct A * ptr=head;
head=head->next;
free (ptr);
return head;
}

struct  A* deleteAtIndex( struct A * head,int index)
{
struct A *p=head;
struct A *q=head->next;
for(int i=0;i<index-1;i++)
{
p=p->next;
q=q->next;
}
p->next=q->next;
free(q);
return head;
}


struct  A* deletelast( struct A * head)
{
struct A *p=head;
struct A *q=head->next;
while(q->next!=0)
{
p=p->next;
q=q->next;
}
p->next=0;
free(q);
return head;
}





void main()
{
struct A * head;
struct A * second;
struct A * third;
struct A * forth;




// allocte memoory for the node in the linked list in heap
head =(struct A *)malloc(sizeof(struct A));
second =(struct A *)malloc(sizeof(struct A));
third =(struct A *)malloc(sizeof(struct A));
forth =(struct A *)malloc(sizeof(struct A));

head-> data=7;
head-> next=second;


second-> data=11; 
second-> next=third;


third-> data=41;
third-> next=forth;

forth-> data=66;
forth-> next=0;

printf("Linklist before insertion\n ");
 linklisttraverse(head);

int l;

int op,c;
while(op!=8)
{
printf("\n1 is insert of the value\n 2 insert between of index\n 3 is dlt of first element\n4 is dlt of the index\n 5 is dlt of the last\n 6 is dlt of end\n 7 is traverse of linkedlist\n 8 is exit of terminal\n");
scanf("%d",&c);
switch(c)
{
case 1:
{
printf("Enter any no. you i\n");
scanf("%d",&l);
 head=insertAtFirst(head,l);
break;
}
case 2:
{
head =insertIndex(head,56,2);
break;
}
case 3:
{
head= deleteFirst(head);

break;
}
case 4:
{
head=deleteAtIndex(head,2);
break;
}
case 5:
{
head= deletelast(head);
break;
}
case 6:
{
head=insertEnd(head,l);
break;
}

case 7:
{
printf("Linklist after insertion\n ");
 linklisttraverse(head);
break;
}
case 8:
{
op=8;
}
}
}

}


